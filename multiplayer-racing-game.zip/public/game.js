class RacingGame {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.socket = null;
        this.playerId = null;
        this.gameState = {
            players: [],
            obstacles: [],
            powerUps: [],
            leaderboard: [],
            gameTime: 0,
            gameId: null,
            totalPlayers: 0
        };
        
        this.input = {
            up: false,
            down: false,
            left: false,
            right: false
        };
        
        this.mapWidth = 3000;
        this.mapHeight = 2000;
        this.camera = {
            x: 0,
            y: 0,
            width: this.canvas.width,
            height: this.canvas.height
        };
        
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.reconnectDelay = 3000;
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupSocket();
        this.setupControls();
        this.setupUI();
        this.gameLoop();
    }
    
    setupCanvas() {
        const resize = () => {
            this.canvas.width = window.innerWidth * 0.6;
            this.canvas.height = window.innerHeight * 0.7;
            this.camera.width = this.canvas.width;
            this.camera.height = this.canvas.height;
        };
        
        resize();
        window.addEventListener('resize', resize);
    }
    
    setupSocket() {
        // IMPORTANT: Update this URL to your Render backend URL after deployment
        const serverUrl = window.location.hostname.includes('localhost') 
            ? 'http://localhost:3000'
            : 'https://multiplayer-racing-game-gadu.onrender.com'; // ← CHANGE THIS AFTER DEPLOYMENT
        
        console.log('Connecting to server:', serverUrl);
        
        this.socket = io(serverUrl, {
            reconnection: true,
            reconnectionAttempts: this.maxReconnectAttempts,
            reconnectionDelay: this.reconnectDelay,
            reconnectionDelayMax: 5000,
            timeout: 20000,
            transports: ['websocket', 'polling']
        });
        
        this.socket.on('connect', () => {
            console.log('✅ Connected to server');
            this.reconnectAttempts = 0;
            document.getElementById('serverInfo').textContent = 'Connected to game server';
            document.getElementById('serverInfo').style.color = '#00ff88';
        });
        
        this.socket.on('connect_error', (error) => {
            console.error('Connection error:', error);
            this.reconnectAttempts++;
            
            const status = document.getElementById('serverInfo');
            status.textContent = `Connecting... (Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`;
            status.style.color = '#ffaa00';
            
            if (this.reconnectAttempts >= this.maxReconnectAttempts) {
                status.textContent = 'Failed to connect. Please refresh the page.';
                status.style.color = '#ff4444';
            }
        });
        
        this.socket.on('init', (data) => {
            console.log('Game initialized:', data);
            this.playerId = data.playerId;
            this.mapWidth = data.mapWidth;
            this.mapHeight = data.mapHeight;
            this.gameState.players = data.players;
            this.gameState.obstacles = data.obstacles;
            this.gameState.powerUps = data.powerUps;
            this.gameState.gameId = data.gameId;
            
            document.getElementById('loadingScreen').style.display = 'none';
            document.getElementById('gameOverlay').style.display = 'flex';
            
            const savedName = localStorage.getItem('racingPlayerName');
            if (savedName) {
                document.getElementById('playerName').value = savedName;
                this.socket.emit('setName', savedName);
            }
        });
        
        this.socket.on('gameState', (state) => {
            this.gameState = state;
            this.updateUI();
        });
        
        this.socket.on('gameStarting', (data) => {
            this.showCountdown(data.time);
        });
        
        this.socket.on('gameStarted', () => {
            console.log('Race started!');
            document.getElementById('gameOverlay').style.display = 'none';
        });
        
        this.socket.on('playerJoined', (player) => {
            this.showChatMessage(`🚗 ${player.name} joined the race`, 'system');
        });
        
        this.socket.on('playerLeft', (data) => {
            this.showChatMessage(`👋 ${data.name} left the race`, 'system');
        });
        
        this.socket.on('playerUpdated', (data) => {
            if (data.oldName) {
                this.showChatMessage(`🔄 ${data.oldName} is now ${data.name}`, 'system');
            }
        });
        
        this.socket.on('chatMessage', (message) => {
            this.showChatMessage(`${message.playerName}: ${message.message}`);
        });
        
        this.socket.on('lapComplete', (data) => {
            const message = data.lap > 3 
                ? `🏁 RACE COMPLETE! Final score: ${data.score}` 
                : `✅ Lap ${data.lap}/${data.totalLaps} complete! +${data.score} points`;
            this.showChatMessage(message, 'system');
        });
        
        this.socket.on('raceComplete', (data) => {
            const positionSuffix = data.position === 1 ? 'st' : data.position === 2 ? 'nd' : data.position === 3 ? 'rd' : 'th';
            this.showChatMessage(`🏆 You finished ${data.position}${positionSuffix} out of ${data.totalPlayers}! Final score: ${data.score}`, 'system');
            
            // Show celebration
            this.showCelebration(data.position);
        });
        
        this.socket.on('powerUpCollected', (powerUp) => {
            this.showChatMessage(`🎯 Collected ${powerUp.type} power-up!`, 'system');
        });
        
        this.socket.on('collision', (data) => {
            this.showChatMessage(`💥 Hit ${data.type} obstacle! Speed reduced by ${data.speedLoss}%`, 'system');
        });
        
        this.socket.on('missileHit', (data) => {
            this.showChatMessage('🚀 Missile hit target!', 'system');
        });
        
        this.socket.on('hitByMissile', (data) => {
            this.showChatMessage('💣 You were hit by a missile!', 'system');
        });
        
        this.socket.on('raceFinished', () => {
            this.showChatMessage('🏁 Race finished! New race starting in 5 seconds...', 'system');
        });
        
        this.socket.on('gameReset', () => {
            this.showChatMessage('🔄 New race started! Get ready...', 'system');
        });
        
        this.socket.on('error', (message) => {
            this.showChatMessage(`❌ Error: ${message}`, 'system');
            if (message.includes('full')) {
                alert(`⚠️ Server is full. Maximum ${message.match(/\d+/)?.[0] || 20} players allowed.`);
            }
        });
        
        this.socket.on('disconnect', (reason) => {
            console.log('Disconnected:', reason);
            this.showChatMessage('🔌 Disconnected from server. Reconnecting...', 'system');
            
            document.getElementById('loadingScreen').style.display = 'flex';
            document.getElementById('loadingScreen').querySelector('p').textContent = 
                'Connection lost. Reconnecting...';
        });
    }
    
    setupControls() {
        // Keyboard controls
        window.addEventListener('keydown', (e) => {
            switch(e.key.toLowerCase()) {
                case 'w':
                case 'arrowup':
                    this.input.up = true;
                    break;
                case 's':
                case 'arrowdown':
                    this.input.down = true;
                    break;
                case 'a':
                case 'arrowleft':
                    this.input.left = true;
                    break;
                case 'd':
                case 'arrowright':
                    this.input.right = true;
                    break;
                case ' ':
                    this.usePowerUp();
                    break;
                case 'e':
                    this.toggleChat();
                    break;
                case 'enter':
                    if (document.activeElement.id !== 'chatInput') {
                        e.preventDefault();
                    }
                    break;
                case 'escape':
                    this.toggleChat();
                    break;
            }
        });
        
        window.addEventListener('keyup', (e) => {
            switch(e.key.toLowerCase()) {
                case 'w':
                case 'arrowup':
                    this.input.up = false;
                    break;
                case 's':
                case 'arrowdown':
                    this.input.down = false;
                    break;
                case 'a':
                case 'arrowleft':
                    this.input.left = false;
                    break;
                case 'd':
                case 'arrowright':
                    this.input.right = false;
                    break;
            }
        });
        
        // Mobile controls
        const addMobileControl = (id, key, isButton = true) => {
            const element = document.getElementById(id);
            if (!element) return;
            
            if (isButton) {
                const startEvent = (e) => {
                    e.preventDefault();
                    this.input[key] = true;
                };
                
                const endEvent = (e) => {
                    e.preventDefault();
                    this.input[key] = false;
                };
                
                element.addEventListener('touchstart', startEvent);
                element.addEventListener('touchend', endEvent);
                element.addEventListener('touchcancel', endEvent);
                element.addEventListener('mousedown', startEvent);
                element.addEventListener('mouseup', endEvent);
                element.addEventListener('mouseleave', endEvent);
            } else {
                element.addEventListener('click', () => this[key]());
            }
        };
        
        addMobileControl('upBtn', 'up');
        addMobileControl('downBtn', 'down');
        addMobileControl('leftBtn', 'left');
        addMobileControl('rightBtn', 'right');
        addMobileControl('usePowerBtn', 'usePowerUp', false);
        
        // Send input to server at 60 FPS
        setInterval(() => {
            if (this.socket && this.socket.connected && this.playerId) {
                this.socket.emit('playerInput', this.input);
            }
        }, 1000/60);
    }
    
    setupUI() {
        // Player name change
        document.getElementById('changeName').addEventListener('click', () => {
            const name = document.getElementById('playerName').value.trim();
            if (name) {
                localStorage.setItem('racingPlayerName', name);
                this.socket.emit('setName', name);
                this.showChatMessage(`Your name changed to ${name}`, 'system');
            }
        });
        
        // Enter key for name change
        document.getElementById('playerName').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('changeName').click();
            }
        });
        
        // Chat
        document.getElementById('sendBtn').addEventListener('click', () => {
            this.sendChatMessage();
        });
        
        document.getElementById('chatInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendChatMessage();
            }
        });
        
        document.getElementById('toggleChat').addEventListener('click', () => {
            this.toggleChat();
        });
    }
    
    updateUI() {
        // Update player count
        document.getElementById('playerCount').textContent = this.gameState.totalPlayers;
        
        // Update timer
        const minutes = Math.floor(this.gameState.gameTime / 60);
        const seconds = this.gameState.gameTime % 60;
        document.getElementById('timer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Update player stats
        const player = this.gameState.players.find(p => p.id === this.playerId);
        if (player) {
            document.getElementById('speed').textContent = Math.round(player.speed * 10);
            document.getElementById('lap').textContent = `${Math.min(player.lap, 3)}/3`;
            document.getElementById('distance').textContent = Math.round(player.distance);
            
            // Find player position in leaderboard
            const position = this.gameState.leaderboard.findIndex(p => p.id === this.playerId) + 1;
            document.getElementById('position').textContent = position > 0 ? `#${position}` : '-';
            
            // Update power-ups display
            const powerUpsContainer = document.getElementById('powerUps');
            powerUpsContainer.innerHTML = '<div class="power-up-label">Power-ups:</div>';
            
            if (player.powerUps && player.powerUps.length > 0) {
                player.powerUps.forEach(powerUp => {
                    const div = document.createElement('div');
                    div.className = 'power-up-item';
                    
                    let icon = '⚡';
                    switch(powerUp) {
                        case 'speed': icon = '⚡'; break;
                        case 'shield': icon = '🛡️'; break;
                        case 'missile': icon = '🚀'; break;
                        case 'boost': icon = '🔥'; break;
                    }
                    
                    div.innerHTML = `${icon} ${powerUp}`;
                    powerUpsContainer.appendChild(div);
                });
            }
        }
        
        // Update leaderboard
        const leaderboardContainer = document.getElementById('leaderboard');
        leaderboardContainer.innerHTML = '<div class="leaderboard-header"><span>Pos</span><span>Name</span><span>Distance</span><span>Lap</span></div>';
        
        this.gameState.leaderboard.forEach((player, index) => {
            const div = document.createElement('div');
            div.className = `leaderboard-item ${player.id === this.playerId ? 'current-player' : ''}`;
            div.innerHTML = `
                <span class="position position-${index + 1}">${index + 1}</span>
                <span>${player.name}</span>
                <span>${player.distance}m</span>
                <span>${player.lap > 3 ? '🏁' : player.lap}</span>
            `;
            leaderboardContainer.appendChild(div);
        });
    }
    
    showCountdown(seconds) {
        const overlay = document.getElementById('gameOverlay');
        const title = document.getElementById('overlayTitle');
        const countdown = document.getElementById('countdown');
        
        overlay.style.display = 'flex';
        title.textContent = 'Race Starting In';
        
        let count = seconds;
        const countdownInterval = setInterval(() => {
            countdown.textContent = count;
            
            // Add sound effect (beep)
            if (count <= 3 && count > 0) {
                this.playSound('beep');
            }
            
            count--;
            
            if (count < 0) {
                clearInterval(countdownInterval);
                overlay.style.display = 'none';
                this.playSound('start');
            }
        }, 1000);
    }
    
    showCelebration(position) {
        if (position <= 3) {
            const messages = [
                "🏆 CHAMPION! 🏆",
                "🥈 GREAT RUN! 🥈", 
                "🥉 WELL DONE! 🥉"
            ];
            
            this.showChatMessage(messages[position - 1], 'system');
            this.playSound('win');
            
            // Add confetti for podium finishes
            if (position === 1) {
                this.createConfetti();
            }
        }
    }
    
    createConfetti() {
        for (let i = 0; i < 100; i++) {
            setTimeout(() => {
                const confetti = document.createElement('div');
                confetti.style.position = 'fixed';
                confetti.style.width = '10px';
                confetti.style.height = '10px';
                confetti.style.background = this.getRandomColor();
                confetti.style.borderRadius = '50%';
                confetti.style.left = `${Math.random() * 100}vw`;
                confetti.style.top = '-10px';
                confetti.style.zIndex = '9999';
                confetti.style.pointerEvents = 'none';
                
                document.body.appendChild(confetti);
                
                // Animate
                const duration = 2000 + Math.random() * 1000;
                const animation = confetti.animate([
                    { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
                    { transform: `translateY(${window.innerHeight}px) rotate(${360 * 3}deg)`, opacity: 0 }
                ], {
                    duration: duration,
                    easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)'
                });
                
                animation.onfinish = () => confetti.remove();
            }, i * 20);
        }
    }
    
    getRandomColor() {
        const colors = ['#ff0055', '#00ffaa', '#00aaff', '#ffaa00', '#ff55ff', '#55ffff'];
        return colors[Math.floor(Math.random() * colors.length)];
    }
    
    playSound(type) {
        // In a real game, you would play actual sound files
        console.log('Playing sound:', type);
        
        // Create a simple beep using Web Audio API
        if (typeof AudioContext !== 'undefined') {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            switch(type) {
                case 'beep':
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
                    oscillator.start();
                    oscillator.stop(audioContext.currentTime + 0.1);
                    break;
                    
                case 'start':
                    oscillator.frequency.setValueAtTime(400, audioContext.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(1200, audioContext.currentTime + 0.5);
                    gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
                    oscillator.start();
                    oscillator.stop(audioContext.currentTime + 0.5);
                    break;
                    
                case 'win':
                    // Play a victory fanfare
                    [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
                        setTimeout(() => {
                            const osc = audioContext.createOscillator();
                            const gain = audioContext.createGain();
                            osc.connect(gain);
                            gain.connect(audioContext.destination);
                            osc.frequency.setValueAtTime(freq, audioContext.currentTime);
                            gain.gain.setValueAtTime(0.1, audioContext.currentTime);
                            gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
                            osc.start();
                            osc.stop(audioContext.currentTime + 0.2);
                        }, i * 200);
                    });
                    break;
            }
        }
    }
    
    showChatMessage(message, type = 'player') {
        const container = document.getElementById('chatMessages');
        const div = document.createElement('div');
        div.className = `chat-message ${type}`;
        
        // Add timestamp
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        div.innerHTML = `<span class="chat-time">[${timeStr}]</span> ${message}`;
        container.appendChild(div);
        
        // Limit messages to 100
        while (container.children.length > 100) {
            container.removeChild(container.firstChild);
        }
        
        container.scrollTop = container.scrollHeight;
    }
    
    sendChatMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        
        if (message && this.socket) {
            this.socket.emit('chatMessage', message);
            input.value = '';
            input.focus();
        }
    }
    
    toggleChat() {
        const chatContainer = document.querySelector('.chat-container');
        const messages = document.getElementById('chatMessages');
        const buttonIcon = document.getElementById('toggleChat').querySelector('i');
        
        if (chatContainer.style.height === '60px' || !chatContainer.style.height) {
            chatContainer.style.height = '300px';
            messages.style.display = 'block';
            buttonIcon.className = 'fas fa-chevron-down';
            document.getElementById('chatInput').focus();
        } else {
            chatContainer.style.height = '60px';
            messages.style.display = 'none';
            buttonIcon.className = 'fas fa-chevron-up';
        }
    }
    
    usePowerUp() {
        if (this.socket && this.socket.connected) {
            this.socket.emit('usePowerUp', 'missile');
        }
    }
    
    updateCamera() {
        const player = this.gameState.players.find(p => p.id === this.playerId);
        if (!player) return;
        
        // Smooth camera follow
        this.camera.x += (player.x - this.camera.width/2 - this.camera.x) * 0.1;
        this.camera.y += (player.y - this.camera.height/2 - this.camera.y) * 0.1;
        
        // Clamp camera to map bounds
        this.camera.x = Math.max(0, Math.min(this.mapWidth - this.camera.width, this.camera.x));
        this.camera.y = Math.max(0, Math.min(this.mapHeight - this.camera.height, this.camera.y));
    }
    
    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Update camera
        this.updateCamera();
        
        // Draw grid background
        this.drawGrid();
        
        // Draw obstacles
        this.gameState.obstacles.forEach(obstacle => {
            this.drawObstacle(obstacle);
        });
        
        // Draw power-ups
        this.gameState.powerUps.forEach(powerUp => {
            this.drawPowerUp(powerUp);
        });
        
        // Draw players
        this.gameState.players.forEach(player => {
            this.drawPlayer(player);
        });
        
        // Draw minimap
        this.drawMinimap();
        
        // Draw HUD
        this.drawHUD();
    }
    
    drawGrid() {
        const gridSize = 100;
        const startX = Math.floor(this.camera.x / gridSize) * gridSize;
        const startY = Math.floor(this.camera.y / gridSize) * gridSize;
        
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        this.ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = startX; x < this.camera.x + this.camera.width; x += gridSize) {
            const screenX = x - this.camera.x;
            this.ctx.beginPath();
            this.ctx.moveTo(screenX, 0);
            this.ctx.lineTo(screenX, this.canvas.height);
            this.ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = startY; y < this.camera.y + this.camera.height; y += gridSize) {
            const screenY = y - this.camera.y;
            this.ctx.beginPath();
            this.ctx.moveTo(0, screenY);
            this.ctx.lineTo(this.canvas.width, screenY);
            this.ctx.stroke();
        }
    }
    
    drawPlayer(player) {
        const screenX = player.x - this.camera.x;
        const screenY = player.y - this.camera.y;
        
        // Skip if off-screen
        if (screenX < -100 || screenX > this.canvas.width + 100 ||
            screenY < -100 || screenY > this.canvas.height + 100) {
            return;
        }
        
        this.ctx.save();
        this.ctx.translate(screenX, screenY);
        this.ctx.rotate(player.rotation);
        
        // Car shadow
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        this.ctx.fillRect(-18, 5, 36, 15);
        
        // Car body
        this.ctx.fillStyle = player.color;
        this.ctx.fillRect(-20, -10, 40, 20);
        
        // Car details
        this.ctx.fillStyle = '#222';
        this.ctx.fillRect(-15, -8, 30, 16);
        
        // Windows
        this.ctx.fillStyle = '#66ccff';
        this.ctx.fillRect(-10, -6, 20, 12);
        
        // Wheels
        this.ctx.fillStyle = '#333';
        this.ctx.fillRect(-25, -15, 10, 5);
        this.ctx.fillRect(15, -15, 10, 5);
        this.ctx.fillRect(-25, 10, 10, 5);
        this.ctx.fillRect(15, 10, 10, 5);
        
        // Shield effect
        if (player.shield > 0) {
            this.ctx.strokeStyle = '#00ffff';
            this.ctx.lineWidth = 3;
            this.ctx.beginPath();
            this.ctx.arc(0, 0, 30, 0, Math.PI * 2);
            this.ctx.stroke();
        }
        
        // Boost effect
        if (player.boost > 0) {
            this.ctx.fillStyle = '#ff9900';
            this.ctx.beginPath();
            this.ctx.moveTo(-25, 0);
            this.ctx.lineTo(-40, -10);
            this.ctx.lineTo(-40, 10);
            this.ctx.closePath();
            this.ctx.fill();
        }
        
        // Current player indicator
        if (player.id === this.playerId) {
            this.ctx.fillStyle = '#ff4444';
            this.ctx.beginPath();
            this.ctx.arc(0, -25, 5, 0, Math.PI * 2);
            this.ctx.fill();
        }
        
        this.ctx.restore();
        
        // Draw player name
        this.ctx.fillStyle = player.id === this.playerId ? '#ff4444' : 'white';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'bottom';
        this.ctx.fillText(player.name, screenX, screenY - 35);
        
        // Draw speed indicator
        this.ctx.fillStyle = '#00ff88';
        this.ctx.font = '10px Arial';
        this.ctx.fillText(`${Math.round(player.speed * 10)} km/h`, screenX, screenY + 35);
    }
    
    drawObstacle(obstacle) {
        const screenX = obstacle.x - this.camera.x;
        const screenY = obstacle.y - this.camera.y;
        
        if (screenX < -100 || screenX > this.canvas.width + 100 ||
            screenY < -100 || screenY > this.canvas.height + 100) {
            return;
        }
        
        this.ctx.save();
        this.ctx.translate(screenX, screenY);
        
        // Shadow
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        if (obstacle.type === 'rock') {
            this.ctx.beginPath();
            this.ctx.ellipse(5, 5, obstacle.width/2, obstacle.height/2, 0, 0, Math.PI * 2);
            this.ctx.fill();
        } else {
            this.ctx.beginPath();
            this.ctx.arc(5, 5, obstacle.width/2, 0, Math.PI * 2);
            this.ctx.fill();
        }
        
        // Obstacle
        this.ctx.fillStyle = obstacle.type === 'rock' ? '#666' : '#8B4513';
        
        if (obstacle.type === 'rock') {
            // Draw rock with texture
            this.ctx.beginPath();
            this.ctx.ellipse(0, 0, obstacle.width/2, obstacle.height/2, 0, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Rock texture
            this.ctx.fillStyle = '#888';
            for (let i = 0; i < 5; i++) {
                const angle = (i / 5) * Math.PI * 2;
                const radius = obstacle.width/4;
                this.ctx.beginPath();
                this.ctx.arc(
                    Math.cos(angle) * radius,
                    Math.sin(angle) * radius,
                    3 + Math.random() * 4,
                    0, Math.PI * 2
                );
                this.ctx.fill();
            }
        } else {
            // Oil spill with rainbow effect
            const gradient = this.ctx.createRadialGradient(0, 0, 0, 0, 0, obstacle.width/2);
            gradient.addColorStop(0, 'rgba(139, 69, 19, 0.8)');
            gradient.addColorStop(0.5, 'rgba(139, 69, 19, 0.4)');
            gradient.addColorStop(1, 'rgba(139, 69, 19, 0.1)');
            
            this.ctx.fillStyle = gradient;
            this.ctx.beginPath();
            this.ctx.arc(0, 0, obstacle.width/2, 0, Math.PI * 2);
            this.ctx.fill();
        }
        
        this.ctx.restore();
    }
    
    drawPowerUp(powerUp) {
        const screenX = powerUp.x - this.camera.x;
        const screenY = powerUp.y - this.camera.y;
        
        if (screenX < -50 || screenX > this.canvas.width + 50 ||
            screenY < -50 || screenY > this.canvas.height + 50) {
            return;
        }
        
        this.ctx.save();
        this.ctx.translate(screenX, screenY);
        
        // Pulsing animation
        const time = Date.now() / 1000;
        const pulse = Math.sin(time * 3) * 3;
        const rotation = time * 2;
        const size = 20 + pulse;
        
        // Draw glow
        const gradient = this.ctx.createRadialGradient(0, 0, size/2, 0, 0, size);
        gradient.addColorStop(0, powerUp.color + 'ff');
        gradient.addColorStop(0.7, powerUp.color + 'aa');
        gradient.addColorStop(1, powerUp.color + '00');
        
        this.ctx.fillStyle = gradient;
        this.ctx.beginPath();
        this.ctx.arc(0, 0, size, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Rotate power-up
        this.ctx.rotate(rotation);
        
        // Draw power-up icon
        this.ctx.fillStyle = 'white';
        this.ctx.font = 'bold 20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        
        let icon = '★';
        switch(powerUp.type) {
            case 'speed': icon = '⚡'; break;
            case 'shield': icon = '🛡️'; break;
            case 'missile': icon = '🚀'; break;
            case 'boost': icon = '🔥'; break;
        }
        
        this.ctx.fillText(icon, 0, 0);
        
        this.ctx.restore();
    }
    
    drawMinimap() {
        const size = 150;
        const padding = 10;
        const x = this.canvas.width - size - padding;
        const y = padding;
        const scale = size / this.mapWidth;
        
        // Background
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        this.ctx.fillRect(x, y, size, size);
        this.ctx.strokeStyle = '#00ff88';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, size, size);
        
        // Draw map boundaries
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.strokeRect(x, y, size, size);
        
        // Draw players on minimap
        this.gameState.players.forEach(player => {
            const miniX = x + player.x * scale;
            const miniY = y + player.y * scale;
            
            this.ctx.fillStyle = player.id === this.playerId ? '#ff4444' : player.color;
            this.ctx.beginPath();
            this.ctx.arc(miniX, miniY, 4, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Draw direction indicator
            this.ctx.strokeStyle = 'white';
            this.ctx.lineWidth = 1;
            this.ctx.beginPath();
            this.ctx.moveTo(miniX, miniY);
            this.ctx.lineTo(
                miniX + Math.cos(player.rotation) * 8,
                miniY + Math.sin(player.rotation) * 8
            );
            this.ctx.stroke();
        });
        
        // Draw camera viewport
        const viewX = x + this.camera.x * scale;
        const viewY = y + this.camera.y * scale;
        const viewWidth = this.camera.width * scale;
        const viewHeight = this.camera.height * scale;
        
        this.ctx.strokeStyle = '#00ffff';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(viewX, viewY, viewWidth, viewHeight);
        
        // Minimap label
        this.ctx.fillStyle = 'white';
        this.ctx.font = '10px Arial';
        this.ctx.textAlign = 'right';
        this.ctx.fillText('MINIMAP', x + size - 5, y + 12);
    }
    
    drawHUD() {
        // Draw game ID in corner
        if (this.gameState.gameId) {
            this.ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillText(`Game: ${this.gameState.gameId.substring(0, 8)}`, 10, 20);
        }
        
        // Draw FPS counter
        if (this.lastFrameTime) {
            const currentTime = performance.now();
            const fps = Math.round(1000 / (currentTime - this.lastFrameTime));
            this.lastFrameTime = currentTime;
            
            this.ctx.fillStyle = fps > 50 ? '#00ff88' : fps > 30 ? '#ffaa00' : '#ff4444';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'right';
            this.ctx.fillText(`${fps} FPS`, this.canvas.width - 10, 20);
        } else {
            this.lastFrameTime = performance.now();
        }
    }
    
    gameLoop() {
        this.draw();
        requestAnimationFrame(() => this.gameLoop());
    }
}

// Start the game when page loads
window.addEventListener('load', () => {
    new RacingGame();
});