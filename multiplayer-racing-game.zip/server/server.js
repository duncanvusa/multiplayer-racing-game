const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);

// Configure CORS for your domain
const io = new Server(server, {
    cors: {
        origin: [
            "https://filepuller.maitengwepost.com",
            "http://localhost:3000",
            process.env.FRONTEND_URL || "http://localhost:3000"
        ],
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// Game configuration
const MAX_PLAYERS = 20;
const TRACK_LENGTH = 5000;
const RACE_DURATION = 120; // seconds
const MAP_WIDTH = 3000;
const MAP_HEIGHT = 2000;

// Game state
let gameState = {
    players: new Map(),
    gameStarted: false,
    raceStartTime: null,
    obstacles: generateObstacles(30),
    powerUps: generatePowerUps(15),
    leaderboard: []
};

// Generate random obstacles
function generateObstacles(count) {
    const obstacles = [];
    for (let i = 0; i < count; i++) {
        obstacles.push({
            id: uuidv4(),
            x: Math.random() * MAP_WIDTH,
            y: Math.random() * MAP_HEIGHT,
            type: Math.random() > 0.5 ? 'rock' : 'oil',
            width: 30 + Math.random() * 40,
            height: 30 + Math.random() * 40
        });
    }
    return obstacles;
}

// Generate power-ups
function generatePowerUps(count) {
    const powerUps = [];
    const types = ['speed', 'shield', 'missile', 'boost'];
    const colors = {
        'speed': '#ff4444',
        'shield': '#4444ff',
        'missile': '#ff8800',
        'boost': '#00ff88'
    };
    
    for (let i = 0; i < count; i++) {
        const type = types[Math.floor(Math.random() * types.length)];
        powerUps.push({
            id: uuidv4(),
            x: Math.random() * MAP_WIDTH,
            y: Math.random() * MAP_HEIGHT,
            type: type,
            color: colors[type],
            active: true
        });
    }
    return powerUps;
}

// Update game state
function updateGameState() {
    const now = Date.now();
    
    // Calculate positions and check collisions
    const activePlayers = Array.from(gameState.players.values()).filter(p => p.active);
    
    // Update leaderboard
    gameState.leaderboard = activePlayers
        .sort((a, b) => {
            // Sort by lap first, then distance
            if (b.lap !== a.lap) return b.lap - a.lap;
            return b.distance - a.distance;
        })
        .map(p => ({
            id: p.id,
            name: p.name,
            distance: Math.round(p.distance),
            speed: Math.round(p.speed * 10),
            lap: p.lap,
            score: p.score,
            color: p.color
        }));
    
    // Emit game state to all players
    io.emit('gameState', {
        players: activePlayers,
        obstacles: gameState.obstacles,
        powerUps: gameState.powerUps.filter(p => p.active),
        leaderboard: gameState.leaderboard.slice(0, 10),
        gameTime: gameState.gameStarted ? 
            Math.max(0, RACE_DURATION - Math.floor((now - gameState.raceStartTime) / 1000)) : 0
    });
}

// Handle socket connections
io.on('connection', (socket) => {
    console.log('New player connected:', socket.id);
    
    if (gameState.players.size >= MAX_PLAYERS) {
        socket.emit('error', 'Server is full (max 20 players)');
        socket.disconnect();
        return;
    }
    
    // Add new player
    const player = {
        id: socket.id,
        name: `Player ${gameState.players.size + 1}`,
        x: Math.random() * MAP_WIDTH,
        y: Math.random() * MAP_HEIGHT,
        rotation: 0,
        speed: 0,
        maxSpeed: 8,
        acceleration: 0.2,
        deceleration: 0.1,
        handling: 0.05,
        color: `hsl(${Math.random() * 360}, 70%, 50%)`,
        distance: 0,
        lap: 1,
        score: 0,
        powerUps: [],
        shield: 0,
        boost: 0,
        active: true,
        lastUpdate: Date.now()
    };
    
    gameState.players.set(socket.id, player);
    
    // Send current game state to new player
    socket.emit('init', {
        playerId: socket.id,
        player,
        mapWidth: MAP_WIDTH,
        mapHeight: MAP_HEIGHT,
        trackLength: TRACK_LENGTH,
        obstacles: gameState.obstacles,
        powerUps: gameState.powerUps.filter(p => p.active),
        players: Array.from(gameState.players.values()).filter(p => p.active)
    });
    
    // Notify other players
    socket.broadcast.emit('playerJoined', player);
    
    // Handle player input
    socket.on('playerInput', (input) => {
        const player = gameState.players.get(socket.id);
        if (!player) return;
        
        const now = Date.now();
        const deltaTime = Math.min(100, now - player.lastUpdate) / 1000;
        player.lastUpdate = now;
        
        // Update player based on input
        if (input.up) {
            player.speed = Math.min(player.speed + player.acceleration, player.maxSpeed);
        } else if (input.down) {
            player.speed = Math.max(player.speed - player.acceleration * 2, -player.maxSpeed * 0.5);
        } else {
            player.speed *= (1 - player.deceleration * deltaTime);
        }
        
        if (input.left) {
            player.rotation -= player.handling * (player.speed > 0 ? 1 : -1);
        }
        if (input.right) {
            player.rotation += player.handling * (player.speed > 0 ? 1 : -1);
        }
        
        // Apply boost if active
        if (player.boost > 0) {
            player.speed = Math.min(player.speed * 1.5, player.maxSpeed * 1.5);
            player.boost = Math.max(0, player.boost - deltaTime);
        }
        
        // Update position
        player.x += Math.cos(player.rotation) * player.speed;
        player.y += Math.sin(player.rotation) * player.speed;
        
        // Keep within map bounds
        player.x = Math.max(0, Math.min(MAP_WIDTH, player.x));
        player.y = Math.max(0, Math.min(MAP_HEIGHT, player.y));
        
        // Update distance
        player.distance += Math.abs(player.speed) * deltaTime;
        
        // Check lap completion
        if (player.distance > TRACK_LENGTH * player.lap) {
            player.lap++;
            player.score += 1000;
            socket.emit('lapComplete', { 
                lap: player.lap, 
                score: player.score,
                totalLaps: 3 
            });
            
            if (player.lap > 3) {
                socket.emit('raceComplete', { 
                    position: gameState.leaderboard.findIndex(p => p.id === socket.id) + 1, 
                    score: player.score 
                });
                player.active = false;
            }
        }
        
        // Check collisions with obstacles
        gameState.obstacles.forEach(obstacle => {
            const dx = player.x - obstacle.x;
            const dy = player.y - obstacle.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 50 && player.shield <= 0) {
                player.speed *= 0.5;
                player.rotation += Math.PI * 0.5; // Spin out
                socket.emit('collision', { type: obstacle.type });
            }
        });
        
        // Check power-up collection
        gameState.powerUps.forEach(powerUp => {
            if (!powerUp.active) return;
            
            const dx = player.x - powerUp.x;
            const dy = player.y - powerUp.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 40) {
                powerUp.active = false;
                player.powerUps.push(powerUp.type);
                
                switch(powerUp.type) {
                    case 'speed':
                        player.maxSpeed += 2;
                        setTimeout(() => {
                            player.maxSpeed -= 2;
                        }, 10000);
                        break;
                    case 'shield':
                        player.shield = 10; // 10 seconds
                        break;
                    case 'boost':
                        player.boost = 5; // 5 seconds
                        break;
                    case 'missile':
                        // Can be used to attack other players
                        break;
                }
                
                socket.emit('powerUpCollected', powerUp);
                io.emit('powerUpCollected', { id: powerUp.id });
            }
        });
        
        // Update shield
        if (player.shield > 0) {
            player.shield = Math.max(0, player.shield - deltaTime);
        }
    });
    
    // Handle player actions
    socket.on('usePowerUp', (powerUpType) => {
        const player = gameState.players.get(socket.id);
        if (!player) return;
        
        const index = player.powerUps.indexOf(powerUpType);
        if (index > -1) {
            player.powerUps.splice(index, 1);
            
            if (powerUpType === 'missile') {
                // Find closest opponent
                const opponents = Array.from(gameState.players.values())
                    .filter(p => p.id !== socket.id && p.active);
                
                if (opponents.length > 0) {
                    const target = opponents.reduce((closest, opponent) => {
                        const dist = Math.sqrt(
                            Math.pow(player.x - opponent.x, 2) + 
                            Math.pow(player.y - opponent.y, 2)
                        );
                        return dist < closest.distance ? { opponent, distance: dist } : closest;
                    }, { distance: Infinity }).opponent;
                    
                    // Slow down target
                    target.speed *= 0.3;
                    
                    socket.emit('missileHit', { target: target.id });
                    io.to(target.id).emit('hitByMissile', { from: player.id });
                }
            }
        }
    });
    
    // Handle chat messages
    socket.on('chatMessage', (message) => {
        const player = gameState.players.get(socket.id);
        if (!player) return;
        
        io.emit('chatMessage', {
            playerId: socket.id,
            playerName: player.name,
            message: message.substring(0, 200), // Limit message length
            timestamp: Date.now()
        });
    });
    
    // Handle player name change
    socket.on('setName', (name) => {
        const player = gameState.players.get(socket.id);
        if (player && name && name.length <= 20) {
            const oldName = player.name;
            player.name = name.substring(0, 20);
            io.emit('playerUpdated', { 
                id: socket.id, 
                name: player.name,
                oldName: oldName 
            });
        }
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('Player disconnected:', socket.id);
        const player = gameState.players.get(socket.id);
        if (player) {
            io.emit('playerLeft', { id: socket.id, name: player.name });
        }
        gameState.players.delete(socket.id);
        
        // If no players left, reset game
        if (gameState.players.size === 0) {
            resetGame();
        }
    });
    
    // Start game if enough players
    if (gameState.players.size >= 1 && !gameState.gameStarted) {
        gameState.gameStarted = true;
        gameState.raceStartTime = Date.now();
        io.emit('gameStarting', { time: 5 });
        
        setTimeout(() => {
            io.emit('gameStarted');
        }, 5000);
    }
});

// Game update loop
setInterval(updateGameState, 1000 / 60); // 60 FPS

// Reset game after completion
function resetGame() {
    gameState.players.forEach(player => {
        player.active = true;
        player.distance = 0;
        player.lap = 1;
        player.score = 0;
        player.x = Math.random() * MAP_WIDTH;
        player.y = Math.random() * MAP_HEIGHT;
        player.powerUps = [];
        player.shield = 0;
        player.boost = 0;
        player.speed = 0;
    });
    
    gameState.obstacles = generateObstacles(30);
    gameState.powerUps = generatePowerUps(15);
    gameState.gameStarted = false;
    gameState.raceStartTime = null;
    
    io.emit('gameReset');
}

// Auto-reset timer
setInterval(() => {
    if (gameState.gameStarted) {
        const elapsed = (Date.now() - gameState.raceStartTime) / 1000;
        if (elapsed >= RACE_DURATION) {
            io.emit('raceFinished');
            setTimeout(resetGame, 10000); // Reset after 10 seconds
        }
    }
}, 1000);

// API endpoint for server status
app.get('/api/status', (req, res) => {
    res.json({
        status: 'online',
        players: gameState.players.size,
        maxPlayers: MAX_PLAYERS,
        gameStarted: gameState.gameStarted,
        uptime: process.uptime()
    });
});

// Serve frontend for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Players connected: ${gameState.players.size}/${MAX_PLAYERS}`);
});