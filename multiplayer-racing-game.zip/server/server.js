const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);

// Get frontend URL from environment or use default
const FRONTEND_URL = 'https://filepuller.maitengwepost.com';
const NODE_ENV = process.env.NODE_ENV || 'production';

console.log('Environment:', NODE_ENV);
console.log('Frontend URL:', FRONTEND_URL);

// Configure CORS - ALLOW YOUR DOMAIN
const io = new Server(server, {
    cors: {
        origin: [
            "https://filepuller.maitengwepost.com",
            "http://filepuller.maitengwepost.com",
            "http://localhost:3000",
            "https://multiplayer-racing-game-gadu.onrender.com",
            "https://*.onrender.com",
            "http://*.onrender.com"
        ],
        methods: ["GET", "POST"],
        credentials: true
    },
    pingTimeout: 60000,
    pingInterval: 25000
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// API endpoint for health checks
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        players: gameState.players.size,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        server: 'multiplayer-racing-game-gadu.onrender.com',
        allowedOrigins: [
            'https://filepuller.maitengwepost.com',
            'https://multiplayer-racing-game-gadu.onrender.com'
        ]
    });
});

// Game configuration
const MAX_PLAYERS = 20;
const TRACK_LENGTH = 5000;
const RACE_DURATION = 120; // 2 minutes
const MAP_WIDTH = 3000;
const MAP_HEIGHT = 2000;
const OBSTACLE_COUNT = 30;
const POWERUP_COUNT = 15;

// Game state
let gameState = {
    players: new Map(),
    gameStarted: false,
    raceStartTime: null,
    obstacles: [],
    powerUps: [],
    leaderboard: [],
    gameId: uuidv4(),
    lastReset: Date.now()
};

// Initialize game objects
function initializeGameObjects() {
    gameState.obstacles = generateObstacles(OBSTACLE_COUNT);
    gameState.powerUps = generatePowerUps(POWERUP_COUNT);
}

// Generate random obstacles
function generateObstacles(count) {
    const obstacles = [];
    for (let i = 0; i < count; i++) {
        obstacles.push({
            id: uuidv4(),
            x: Math.random() * MAP_WIDTH,
            y: Math.random() * MAP_HEIGHT,
            type: Math.random() > 0.5 ? 'rock' : 'oil',
            width: 30 + Math.random() * 40,
            height: 30 + Math.random() * 40
        });
    }
    return obstacles;
}

// Generate power-ups
function generatePowerUps(count) {
    const powerUps = [];
    const types = ['speed', 'shield', 'missile', 'boost'];
    const colors = {
        'speed': '#ff4444',
        'shield': '#4444ff',
        'missile': '#ff8800',
        'boost': '#00ff88'
    };
    
    for (let i = 0; i < count; i++) {
        const type = types[Math.floor(Math.random() * types.length)];
        powerUps.push({
            id: uuidv4(),
            x: Math.random() * MAP_WIDTH,
            y: Math.random() * MAP_HEIGHT,
            type: type,
            color: colors[type],
            active: true
        });
    }
    return powerUps;
}

// Calculate distance between two points
function calculateDistance(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

// Update game state
function updateGameState() {
    const now = Date.now();
    
    // Get active players
    const activePlayers = Array.from(gameState.players.values()).filter(p => p.active);
    
    // Update leaderboard
    gameState.leaderboard = activePlayers
        .sort((a, b) => {
            // Sort by lap (descending), then distance (descending)
            if (b.lap !== a.lap) return b.lap - a.lap;
            return b.distance - a.distance;
        })
        .map((player, index) => ({
            id: player.id,
            name: player.name,
            distance: Math.round(player.distance),
            speed: Math.round(player.speed * 10),
            lap: Math.min(player.lap, 3),
            score: player.score,
            color: player.color,
            position: index + 1
        }));
    
    // Emit game state to all players
    io.emit('gameState', {
        players: activePlayers,
        obstacles: gameState.obstacles,
        powerUps: gameState.powerUps.filter(p => p.active),
        leaderboard: gameState.leaderboard.slice(0, 15),
        gameTime: gameState.gameStarted ? 
            Math.max(0, RACE_DURATION - Math.floor((now - gameState.raceStartTime) / 1000)) : 0,
        gameId: gameState.gameId,
        totalPlayers: activePlayers.length
    });
}

// Reset game
function resetGame() {
    console.log('Resetting game...');
    
    gameState.players.forEach(player => {
        player.active = true;
        player.distance = 0;
        player.lap = 1;
        player.score = 0;
        player.x = Math.random() * MAP_WIDTH;
        player.y = Math.random() * MAP_HEIGHT;
        player.rotation = Math.random() * Math.PI * 2;
        player.speed = 0;
        player.powerUps = [];
        player.shield = 0;
        player.boost = 0;
        player.lastUpdate = Date.now();
    });
    
    initializeGameObjects();
    gameState.gameStarted = false;
    gameState.raceStartTime = null;
    gameState.gameId = uuidv4();
    gameState.lastReset = Date.now();
    
    io.emit('gameReset', { gameId: gameState.gameId });
    console.log('Game reset complete');
}

// Game update loop (60 FPS)
setInterval(updateGameState, 1000 / 60);

// Auto-reset timer (every 2.5 minutes)
setInterval(() => {
    if (gameState.gameStarted) {
        const elapsed = (Date.now() - gameState.raceStartTime) / 1000;
        if (elapsed >= RACE_DURATION + 30) { // Extra 30 seconds after race ends
            io.emit('raceFinished');
            setTimeout(resetGame, 5000); // Reset after 5 seconds
        }
    }
}, 1000);

// Initialize game objects
initializeGameObjects();

// Socket.IO connection handling
io.on('connection', (socket) => {
    console.log('Player connected:', socket.id, 'from:', socket.handshake.headers.origin);
    
    // Check if server is full
    if (gameState.players.size >= MAX_PLAYERS) {
        socket.emit('error', `Server is full (max ${MAX_PLAYERS} players)`);
        socket.disconnect();
        return;
    }
    
    // Create new player
    const player = {
        id: socket.id,
        name: `Player ${gameState.players.size + 1}`,
        x: Math.random() * MAP_WIDTH,
        y: Math.random() * MAP_HEIGHT,
        rotation: Math.random() * Math.PI * 2,
        speed: 0,
        maxSpeed: 8,
        acceleration: 0.2,
        deceleration: 0.1,
        handling: 0.05,
        color: `hsl(${Math.random() * 360}, 70%, 50%)`,
        distance: 0,
        lap: 1,
        score: 0,
        powerUps: [],
        shield: 0,
        boost: 0,
        active: true,
        lastUpdate: Date.now(),
        connectedAt: Date.now()
    };
    
    gameState.players.set(socket.id, player);
    
    // Send initialization data to player
    socket.emit('init', {
        playerId: socket.id,
        mapWidth: MAP_WIDTH,
        mapHeight: MAP_HEIGHT,
        trackLength: TRACK_LENGTH,
        totalLaps: 3,
        obstacles: gameState.obstacles,
        powerUps: gameState.powerUps.filter(p => p.active),
        players: Array.from(gameState.players.values()).filter(p => p.active),
        gameId: gameState.gameId
    });
    
    // Notify other players
    socket.broadcast.emit('playerJoined', {
        id: socket.id,
        name: player.name,
        color: player.color
    });
    
    // Start game if we have at least 1 player (changed from 2 for testing)
    if (gameState.players.size >= 1 && !gameState.gameStarted) {
        gameState.gameStarted = true;
        gameState.raceStartTime = Date.now() + 5000; // Start in 5 seconds
        
        io.emit('gameStarting', { 
            time: 5,
            raceDuration: RACE_DURATION
        });
        
        setTimeout(() => {
            io.emit('gameStarted');
            console.log('Race started with', gameState.players.size, 'players');
        }, 5000);
    }
    
    // Handle player input
    socket.on('playerInput', (input) => {
        const player = gameState.players.get(socket.id);
        if (!player || !player.active) return;
        
        const now = Date.now();
        const deltaTime = Math.min(100, now - player.lastUpdate) / 1000;
        player.lastUpdate = now;
        
        // Handle movement input
        if (input.up) {
            player.speed = Math.min(player.speed + player.acceleration, player.maxSpeed);
        } else if (input.down) {
            player.speed = Math.max(player.speed - player.acceleration * 2, -player.maxSpeed * 0.5);
        } else {
            player.speed *= (1 - player.deceleration * deltaTime);
        }
        
        if (input.left) {
            player.rotation -= player.handling * (player.speed > 0 ? 1 : -1);
        }
        if (input.right) {
            player.rotation += player.handling * (player.speed > 0 ? 1 : -1);
        }
        
        // Apply boost
        if (player.boost > 0) {
            player.speed = Math.min(player.speed * 1.5, player.maxSpeed * 1.5);
            player.boost = Math.max(0, player.boost - deltaTime);
        }
        
        // Update position
        player.x += Math.cos(player.rotation) * player.speed;
        player.y += Math.sin(player.rotation) * player.speed;
        
        // Keep within bounds
        player.x = Math.max(0, Math.min(MAP_WIDTH, player.x));
        player.y = Math.max(0, Math.min(MAP_HEIGHT, player.y));
        
        // Update distance
        player.distance += Math.abs(player.speed) * deltaTime;
        
        // Check lap completion
        if (player.distance > TRACK_LENGTH * player.lap) {
            player.lap++;
            player.score += 1000;
            
            socket.emit('lapComplete', { 
                lap: player.lap, 
                score: player.score,
                totalLaps: 3
            });
            
            // Race finished
            if (player.lap > 3) {
                const position = gameState.leaderboard.findIndex(p => p.id === socket.id) + 1;
                socket.emit('raceComplete', { 
                    position: position,
                    score: player.score,
                    totalPlayers: gameState.players.size
                });
                
                player.active = false;
            }
        }
        
        // Check collisions with obstacles
        gameState.obstacles.forEach(obstacle => {
            const distance = calculateDistance(player.x, player.y, obstacle.x, obstacle.y);
            const collisionRadius = 25 + (obstacle.width / 2);
            
            if (distance < collisionRadius && player.shield <= 0) {
                player.speed *= 0.5;
                player.rotation += Math.PI * 0.5; // Spin 90 degrees
                socket.emit('collision', { 
                    type: obstacle.type,
                    speedLoss: 50
                });
            }
        });
        
        // Check power-up collection
        gameState.powerUps.forEach(powerUp => {
            if (!powerUp.active) return;
            
            const distance = calculateDistance(player.x, player.y, powerUp.x, powerUp.y);
            
            if (distance < 40) {
                powerUp.active = false;
                player.powerUps.push(powerUp.type);
                
                // Apply power-up effects
                switch(powerUp.type) {
                    case 'speed':
                        player.maxSpeed += 2;
                        setTimeout(() => {
                            if (player.maxSpeed > 8) player.maxSpeed -= 2;
                        }, 10000);
                        break;
                    case 'shield':
                        player.shield = 10; // 10 seconds
                        break;
                    case 'boost':
                        player.boost = 5; // 5 seconds
                        break;
                    case 'missile':
                        // Can be used later
                        break;
                }
                
                socket.emit('powerUpCollected', powerUp);
                socket.broadcast.emit('powerUpCollected', { id: powerUp.id });
                
                // Regenerate power-up after 30 seconds
                setTimeout(() => {
                    powerUp.active = true;
                    powerUp.x = Math.random() * MAP_WIDTH;
                    powerUp.y = Math.random() * MAP_HEIGHT;
                }, 30000);
            }
        });
        
        // Update shield
        if (player.shield > 0) {
            player.shield = Math.max(0, player.shield - deltaTime);
        }
    });
    
    // Handle power-up usage
    socket.on('usePowerUp', (powerUpType) => {
        const player = gameState.players.get(socket.id);
        if (!player) return;
        
        const index = player.powerUps.indexOf(powerUpType);
        if (index > -1) {
            player.powerUps.splice(index, 1);
            
            if (powerUpType === 'missile') {
                // Find closest opponent
                const opponents = Array.from(gameState.players.values())
                    .filter(p => p.id !== socket.id && p.active);
                
                if (opponents.length > 0) {
                    const target = opponents.reduce((closest, opponent) => {
                        const dist = calculateDistance(player.x, player.y, opponent.x, opponent.y);
                        return dist < closest.distance ? { opponent, distance: dist } : closest;
                    }, { distance: Infinity }).opponent;
                    
                    if (target) {
                        target.speed *= 0.3;
                        target.rotation += Math.PI; // 180 degree spin
                        
                        socket.emit('missileHit', { target: target.id });
                        io.to(target.id).emit('hitByMissile', { from: player.id });
                    }
                }
            }
        }
    });
    
    // Handle chat messages
    socket.on('chatMessage', (message) => {
        const player = gameState.players.get(socket.id);
        if (!player || !message || message.trim().length === 0) return;
        
        const trimmedMessage = message.trim().substring(0, 200);
        
        io.emit('chatMessage', {
            playerId: socket.id,
            playerName: player.name,
            message: trimmedMessage,
            timestamp: Date.now(),
            color: player.color
        });
    });
    
    // Handle name change
    socket.on('setName', (name) => {
        const player = gameState.players.get(socket.id);
        if (player && name && name.trim().length > 0 && name.length <= 20) {
            const oldName = player.name;
            player.name = name.trim().substring(0, 20);
            
            io.emit('playerUpdated', { 
                id: socket.id, 
                name: player.name,
                oldName: oldName 
            });
        }
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('Player disconnected:', socket.id);
        const player = gameState.players.get(socket.id);
        
        if (player) {
            io.emit('playerLeft', { 
                id: socket.id, 
                name: player.name 
            });
            gameState.players.delete(socket.id);
        }
        
        // Reset game if no players left
        if (gameState.players.size === 0) {
            resetGame();
        }
    });
    
    // Error handling
    socket.on('error', (error) => {
        console.error('Socket error:', error);
    });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`🌐 Environment: ${NODE_ENV}`);
    console.log(`🎮 Max players: ${MAX_PLAYERS}`);
    console.log(`🔄 Race duration: ${RACE_DURATION} seconds`);
    console.log(`🗺️ Map size: ${MAP_WIDTH}x${MAP_HEIGHT}`);
    console.log(`🔧 Health check: https://multiplayer-racing-game-gadu.onrender.com/api/health`);
    console.log(`✅ Allowed origins:`);
    console.log(`   - https://filepuller.maitengwepost.com`);
    console.log(`   - https://multiplayer-racing-game-gadu.onrender.com`);
});